// Example of fetch with promise rather than async
//function getTime() {


const getJokeByType = function(){
  let APIendPoint = 'http://192.168.206.34:3000/jokes?type=';
  let jTypeValue = document.getElementById('joketype').value;
  let jCount = '&count='
  let jCountValue = document.getElementById('jokecount').value
  console.log(APIendPoint+jTypeValue+jCount+jCountValue);

fetch(APIendPoint+jTypeValue+jCount+jCountValue)
  .then( response => response.json())
  .then(data => {
    const jokeElement = document.getElementById('jokes');
    let html = `
      <table class='jokeTable'>
      <th>ID</th><th>Joke Type</th><th>Setup</th><th>Punchline</th>`;

    for (let i=0; i < data.length; i++) {
      html+=`
        <tr>
          <td> ${data[i].id} </td>
          <td> ${data[i].type} </td>
          <td> ${data[i].setup} </td>
          <td> ${data[i].punchline} </td>
        </tr>
      `
    };

    html+=`</table>`;
    jokeElement.innerHTML = html;
  })

}


