// Example of fetch with promise rather than async
//function getTime() {


const getResults = function(){
  let APIendPoint = 'http://20.117.80.208:3000/result?lName=';
  let lName = document.getElementById('lastName').value;
  APIendPoint+=lName;
  console.log(APIendPoint);

fetch(APIendPoint)
  .then( response => response.json())
  .then(data => {
    const resultsElement = document.getElementById('results');
    let html = `
      <table class='resTable'>
      <th>ID</th><th>First Name</th><th>Last Name</th><th>Score</th>`;

    for (let i=0; i < data.length; i++) {
      html+=`
        <tr>
          <td> ${data[i].id} </td>
          <td> ${data[i].fName} </td>
          <td> ${data[i].lName} </td>
          <td> ${data[i].result} </td>
        </tr>
      `
    };

    html+=`</table>`;
    resultsElement.innerHTML =html;
  })

}
