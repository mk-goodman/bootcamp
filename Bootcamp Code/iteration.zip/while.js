let i=0; // i is not part of the loop construct

while (i < 10) {
  console.log(`i=${i}`);
  i++; // This will eventually terminate the loop
}