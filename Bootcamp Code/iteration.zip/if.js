let x = 3, y = 4;

if (x < y) console.log(`x is less than y`);
else console.log(`x is greater than or equal to y`);

// In a block of statements inside {}, all statements are executed

if (x + 1 == y) {
  console.log(`This is a block statement in the true block`);
  console.log(`x+1 is equal to y`);
}
else {
  console.log(`This is a block statement in the false block`);
  console.log(`x+1 is not equal to y`);
}