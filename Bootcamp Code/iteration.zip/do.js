i=0;

do {
  console.log(`i=${i}`);
  i++; // This will eventually terminate the loop
} while (i < 10)